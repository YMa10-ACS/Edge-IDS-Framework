#!/usr/bin/env python
"""
Description: Edge encoder entrypoint
Date: 2026-03-10
Author: Yaoquan Ma
"""

import argparse
import json
import os
import sys

import torch
import numpy as np

CURRENT_DIR = os.path.dirname(__file__)
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from support import load_dataset, transfer_embedding, data_preprocess
from PCA.encoder import PCAEncoder
from Feature_Selection.encoder import FSEncoder
from ResNeXt.encoder import RNEncoder


DATASET_PATH = os.path.join(PROJECT_ROOT, "dataset/Edge-IIoTset/")
DATASET = os.path.join(DATASET_PATH, "ML-EdgeIIoT-dataset 2.csv")


def get_device(device_name):
    if device_name == "cpu":
        return "cpu"
    if device_name == "mps":
        return "mps" if torch.backends.mps.is_available() else "cpu"
    if device_name == "cuda":
        return "cuda" if torch.cuda.is_available() else "cpu"
    raise ValueError("Device must be cpu, mps, or cuda")


def encode_features(X, y, encode_type):
    encoder_mapping = {
        "feature_selection": FSEncoder(),
        "pca": PCAEncoder(n_components=16),
        "resnext16": RNEncoder(embedding_dim=16),
        "resnext24": RNEncoder(embedding_dim=24),
        "resnext32": RNEncoder(embedding_dim=32),
    }
    if encode_type not in encoder_mapping:
        raise ValueError(
            f"Unknown encoder '{encode_type}', choose from {list(encoder_mapping.keys())}"
        )

    model = encoder_mapping[encode_type]
    embedding, metadata = model.forward(X)

    labels = y.to_numpy(dtype=np.float32).reshape(-1, 1)
    if labels is not None:
        if len(labels) != embedding.shape[0]:
            raise ValueError(
                f"labels length ({len(labels)}) must match embedding rows ({embedding.shape[0]})"
            )
    embedding_with_label = np.concatenate([embedding, labels], axis=1).astype(np.float32)


    # Ensure metadata is JSON serializable before sending as header.
    json.dumps(metadata)

    return embedding_with_label, metadata


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default=DATASET)
    parser.add_argument("--percentage", type=float, default=1.0)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--encoder", default="pca")
    args = parser.parse_args()

    device = get_device(args.device)
    print("Using device:", device)
    print(f"PROJECT_ROOT = {PROJECT_ROOT}\nDATASET_PATH = {DATASET_PATH}\nDATASET = {args.dataset}")

    df = load_dataset(args.dataset, args.percentage)
    y = df["Attack_label"].copy()
    X = data_preprocess(df)

    embedding, metadata = encode_features(X, y, args.encoder)
    transfer_embedding(embedding, metadata)


if __name__ == "__main__":
    main()
