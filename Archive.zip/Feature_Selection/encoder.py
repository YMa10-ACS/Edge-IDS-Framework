"""
Description: Feature Selection Encoder
Date: 2026-03-10
Author: Yaoquan Ma
"""

import numpy as np


class FSEncoder:
    def __init__(self):
        """
        selected_features: list of feature indices to keep
        """
        self.selected_features = None
        self.scaler = StandardScaler()

    def forward(self, X):
        """
        Encode input features
        """
        if self.selected_features is not None:
            X = X[:, self.selected_features]

        # scaling
        X_scaled = self.scaler.transform(X)

        embedding = X_scaled.astype("float32")

        metadata = {
            "shape": list(embedding.shape),
            "dtype": str(embedding.dtype)
        }

        return embedding, metadata
